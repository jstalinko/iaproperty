<template>
    <div>
        <section class="flex flex-col items-center bg-accent pt-20 pb-56 relative">
			<h2 class="text-8xl text-gray-500 text-shadow-custom text-center mb-10">
				Testimoni
			</h2>
			<div class="flex justify-center rounded-xl gap-10 bg-[#eeeeee] px-10 pt-10 pb-72 w-3/4">
				<div class="rounded-lg bg-white p-5">
					<div class="flex justify-between items-center">
						<div class="flex justify-center items-center gap-2">
							<img class="w-14 rounded-full" src="/assets/images/richard.png" alt="" />
							<div class="flex flex-col text-gray-600">
								<p class="font-bold text-sm">Richard Sample</p>
								<p class="text-xs">Happy Customer</p>
							</div>
						</div>
						<i class="fa fa-quote-right text-5xl text-purple-600"></i>
					</div>
					<div class="flex flex-col">
						<p class="text-gray-600 text-sm mt-3 leading-tight">
							Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi
							temporibus, est veritatis nesciunt iusto saepe officiis dolorum
							dolores libero sit, eum sint delectus nihil deserunt.
						</p>
						<div class="flex justify-end gap-2">
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
						</div>
					</div>
				</div>
				<div class="rounded-lg bg-white p-5">
					<div class="flex justify-between items-center">
						<div class="flex justify-center items-center gap-2">
							<img class="w-14 rounded-full" src="/assets/images/christian.png" alt="" />
							<div class="flex flex-col text-gray-600">
								<p class="font-bold text-sm">Christian Sample</p>
								<p class="text-xs">Happy Customer</p>
							</div>
						</div>
						<i class="fa fa-quote-right text-5xl text-purple-600"></i>
					</div>
					<div class="flex flex-col">
						<p class="text-gray-600 text-sm mt-3 leading-tight">
							Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi
							temporibus, est veritatis nesciunt iusto saepe officiis dolorum
							dolores libero sit, eum sint delectus nihil deserunt.
						</p>
						<div class="flex justify-end gap-2">
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
						</div>
					</div>
				</div>
				<div class="rounded-lg bg-white p-5">
					<div class="flex justify-between items-center">
						<div class="flex justify-center items-center gap-2">
							<img class="w-14 rounded-full" src="/assets/images/lucas.png" alt="" />
							<div class="flex flex-col text-gray-600">
								<p class="font-bold text-sm">Lucas Sample</p>
								<p class="text-xs">Happy Customer</p>
							</div>
						</div>
						<i class="fa fa-quote-right text-5xl text-purple-600"></i>
					</div>
					<div class="flex flex-col">
						<p class="text-gray-600 text-sm mt-3 leading-tight">
							Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi
							temporibus, est veritatis nesciunt iusto saepe officiis dolorum
							dolores libero sit, eum sint delectus nihil deserunt.
						</p>
						<div class="flex justify-end gap-2">
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
							<i class="fa fa-star text-3xl text-yellow-400"></i>
						</div>
					</div>
				</div>
			</div>
			<div class="flex w-full absolute  bottom-0 ">
				<img src="/assets/images/bg-testimonials.png" alt="" />
			</div>
		</section>
    </div>
</template>