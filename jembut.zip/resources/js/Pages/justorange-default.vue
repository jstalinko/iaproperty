<template>
	<div>
		<Navbar />

		<section class="grid grid-cols-2 gap-4 py-20 relative max-h-lvh">
			<div>
				<img src="/assets/images/bg-hero-l.png" alt="" />
			</div>
			<div class="flex flex-col items-center">
				<img class="mb-10" src="/assets/images/bg-hero-r.png" alt="" />
				<h1 class="text-7xl font-bold w-2/3 mb-5">
					<div class="text-[#FEC43C]">IA PROJECT</div>
					<div class="text-secondary text-end">PROPERTY</div>
				</h1>
				<p class="text-secondary w-3/4 text-lg text-center">
					Temukan pengalaman berbelanja furniture ditangani langsung oleh ahli di bidangnya dengan kualitas
					internasional.
				</p>
			</div>
		
		</section>

		<section class="bg-[#ffcc4c] py-20 px-64">
			<div class="flex justify-between">
				<h2 class="text-[#333333] text-4xl ">Rekomendasi Produk</h2>
				<a class="flex items-center gap-2" href="#">
					Tampilkan semua
					<i class="fa fa-long-arrow-right"></i>
				</a>
			</div>

			<div class="grid grid-cols-5 mt-32 gap-x-5 gap-y-32">
				<div
					class="flex flex-col items-center relative bg-[#EEE] rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-10" src="/assets/images/pink-float-chair.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Pink Float Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-14" src="/assets/images/modern-nature.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Modern Nature Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-20" src="/assets/images/comfort-zone.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Comfort Zone Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-16" src="/assets/images/hood-relax.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Hood Relax Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-20" src="/assets/images/one-stand.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">One Stand Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-32 absolute -top-20" src="/assets/images/red.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Best Selling Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-32 absolute -top-28" src="/assets/images/pod.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Best Selling Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-48 absolute -top-24" src="/assets/images/sofa.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Best Selling Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-16" src="/assets/images/lamp.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Best Selling Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
				<div
					class="flex flex-col items-center relative bg-white rounded-lg hover:outline outline-1 outline-black py-5 px-1">
					<img class="w-40 absolute -top-20" src="/assets/images/white.png" alt="" />

					<div class="my-10 text-center text-gray-600">
						<h4 class="text-xl font-bold my-5">Best Selling Chair</h4>
						<p class="text-xs text-center">
							Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam,
							illo! Nobis, distinctio veniam. Eos, doloremque.
						</p>
					</div>
					<div class="flex justify-between items-center gap-5">
						<button
							class="bg-secondary py-1 px-10 rounded-xl flex justify-center items-center gap-2 text-white font-bold">
							<i class="fa fa-shopping-cart"></i>
							Cart
						</button>
						<i class="fa fa-heart-o text-accent-dark"></i>
					</div>
				</div>
			</div>
		</section>
		<CategoryPage :Categories="Categories" :SubCategories="SubCategories" :ActiveCat="ActiveCat" />

		<ProductPage :Products="Products" :HeadTitle="HeadTitle" :Action="Action" />

		<Testimonial/>

		<section class="flex justify-center gap-32 bg-[#222831] px-72 py-10">
			<div class="flex w-2/3 justify-center gap-5">
				<img src="/assets/images/sign-up.png" alt="" />
				<div>
					<h4 class="text-3xl font-bold text-[#EEEEEE]">
						Tartarik dengan produk kami?
					</h4>
					<p class="text-white text-xl">
						Jangan lewatkan penawaran menarik dan terbaru dari kami,
						dengan memasukan nomer whatsapp anda. 
					</p>
				</div>
			</div>
			<form class="w-1/3" action="#">
				<div class="flex flex-col justify-center items-center gap-5">
					<input type="email" class="bg-white text-gray-500 rounded-full py-3 text-center w-full border-2"
						placeholder="Nomor kamu!" />
					<input type="submit"
						class="bg-transparent border border-white text-white rounded-full py-3 text-center w-full"
						value="Dapatkan penawaran" />
				</div>
			</form>
		</section>

		<Footer />
	</div>
</template>


<script setup>
import Navbar from '../Components/Navbar.vue';
import Footer from '../Components/Footer.vue';
import CategoryPage from '../Components/CategoryPage.vue';
import Testimonial from '../Components/Testimonial.vue';
import ProductPage from '../Components/ProductPage.vue';
defineProps({Products: Object , Categories: Object , SubCategories: Object , ActiveCat: String});
const HeadTitle = 'Produk Terbaru';
const Action = 'all';
</script>