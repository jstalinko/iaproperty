<?php

namespace App\Filament\Resources\LinkerResource\Pages;

use App\Filament\Resources\LinkerResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateLinker extends CreateRecord
{
    protected static string $resource = LinkerResource::class;
}
